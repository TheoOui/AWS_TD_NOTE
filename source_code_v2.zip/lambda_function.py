from datetime import datetime
import json

import boto3


def lambda_handler(event, context):
    client = boto3.client("lambda")

    response = client.invoke(
        FunctionName="EsgiAlM2UsersFrankfurt", Payload=json.dumps({"uid": "uid42"})
    )
    content = json.loads(response["Payload"].read().decode())

    year = content["birthyear"]
    return {"age": datetime.now().year - year}
